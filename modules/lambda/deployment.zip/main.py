import boto3
import os
from datetime import datetime, time
from zoneinfo import ZoneInfo  # built-in từ Python 3.9

# AWS clients
dynamodb = boto3.resource("dynamodb")
ec2 = boto3.client("ec2")
rds = boto3.client("rds")

# Lấy tên bảng DynamoDB từ biến môi trường
TABLE_NAME = os.getenv("TABLE_NAME")

def lambda_handler(event, context):
    # --- Quét DynamoDB để lấy toàn bộ schedule ---
    table = dynamodb.Table(TABLE_NAME)
    response = table.scan()
    items = response.get("Items", [])

    # Lấy giờ hiện tại UTC
    now_utc = datetime.utcnow()

    for cfg in items:
        schedule = cfg["ScheduleTag"]

        # --- Tính giờ hiện tại theo Timezone ---
        tz = ZoneInfo(cfg["Timezone"])
        now_local = now_utc.replace(tzinfo=ZoneInfo("UTC")).astimezone(tz)
        current_time = now_local.time()  # datetime.time object

        print(f"[{schedule}] Local time: {now_local.strftime('%H:%M')}")

        # Lấy giờ start/stop cho EC2 và RDS
        ec2_start = _parse_time(cfg.get("EC2Start"))
        ec2_stop = _parse_time(cfg.get("EC2Stop"))
        rds_start = _parse_time(cfg.get("RDSStart"))
        rds_stop = _parse_time(cfg.get("RDSStop"))

        # --- EC2 ---
        if _is_within(current_time, ec2_start, ec2_stop):
            _start_ec2(schedule)
        else:
            _stop_ec2(schedule)

        # --- RDS ---
        if _is_within(current_time, rds_start, rds_stop):
            _start_rds(schedule)
        else:
            _stop_rds(schedule)

    return {"statusCode": 200, "body": "Done"}


# ====== Helpers ======
def _parse_time(tstr):
    """Chuyển string HH:MM thành datetime.time"""
    if not tstr:
        return None
    h, m = map(int, tstr.split(":"))
    return time(h, m)

def _is_within(now, start, stop):
    """Check nếu now nằm trong [start, stop). Hỗ trợ cả khi stop < start (qua ngày)"""
    if not start or not stop:
        return False
    if start < stop:
        return start <= now < stop
    else:  # ví dụ: start=22:00, stop=06:00 hôm sau
        return now >= start or now < stop


# ====== EC2 functions ======
def _start_ec2(schedule):
    instances = ec2.describe_instances(
        Filters=[{"Name": "tag:Schedule", "Values": [schedule]}]
    )
    ids = [i["InstanceId"] for r in instances["Reservations"] for i in r["Instances"]]
    if ids:
        print(f"[EC2] Starting: {ids}")
        ec2.start_instances(InstanceIds=ids)

def _stop_ec2(schedule):
    instances = ec2.describe_instances(
        Filters=[{"Name": "tag:Schedule", "Values": [schedule]}]
    )
    ids = [i["InstanceId"] for r in instances["Reservations"] for i in r["Instances"]]
    if ids:
        print(f"[EC2] Stopping: {ids}")
        ec2.stop_instances(InstanceIds=ids)


# ====== RDS functions ======
def _start_rds(schedule):
    dbs = rds.describe_db_instances()
    for db in dbs["DBInstances"]:
        tags = rds.list_tags_for_resource(ResourceName=db["DBInstanceArn"])["TagList"]
        if any(t["Key"] == "Schedule" and t["Value"] == schedule for t in tags):
            print(f"[RDS] Starting: {db['DBInstanceIdentifier']}")
            rds.start_db_instance(DBInstanceIdentifier=db["DBInstanceIdentifier"])

def _stop_rds(schedule):
    dbs = rds.describe_db_instances()
    for db in dbs["DBInstances"]:
        tags = rds.list_tags_for_resource(ResourceName=db["DBInstanceArn"])["TagList"]
        if any(t["Key"] == "Schedule" and t["Value"] == schedule for t in tags):
            print(f"[RDS] Stopping: {db['DBInstanceIdentifier']}")
            rds.stop_db_instance(DBInstanceIdentifier=db["DBInstanceIdentifier"])
